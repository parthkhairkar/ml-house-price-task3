# 🏡 California House Price Prediction — Task 3
### Model Validation · Overfitting Control · Hyperparameter Tuning

![Python](https://img.shields.io/badge/Python-3.12-blue?logo=python&logoColor=white)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.x-orange?logo=scikit-learn&logoColor=white)
![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-F37626?logo=jupyter&logoColor=white)
![GridSearchCV](https://img.shields.io/badge/GridSearchCV-Tuned-brightgreen)
![CrossValidation](https://img.shields.io/badge/Cross--Validation-5--Fold-blueviolet)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Complete-brightgreen)

---

## 📌 Project Overview

This is **Task 3** of the **Maincrafts Technology AI/ML Internship**, building directly on the multi-model comparison from Task 2.

> Task 2 asked: *"Which model is most accurate?"*  
> Task 3 asks: *"Which model is most **reliable** — and can we make it even better?"*

This project demonstrates how professional ML engineers go beyond basic model training to build **production-ready, generalizable models** using cross-validation and hyperparameter tuning.

---

## 🎯 What Was Achieved

| Goal | Outcome |
|---|---|
| Detect overfitting | Untuned tree had Train RMSE ≈ 0.000 vs Test RMSE 0.4159 — confirmed overfitting |
| Reduce overfitting gap | Gap reduced from **0.4159 → 0.020** (95% reduction) via GridSearchCV |
| Cross-validate performance | 5-fold CV confirmed stable R² > 0.91 across all folds |
| Tune hyperparameters | Best params found: `max_depth=7`, `min_samples_split=10` |
| Select best model | Tuned Decision Tree — R² = **0.9161**, RMSE = **0.3046** |

---

## 📊 Final Results

| Model | RMSE ↓ | R² Score ↑ | CV RMSE | Overfit Risk |
|---|---|---|---|---|
| Linear Regression | 0.4241 | 0.8374 | 0.4202 | Low |
| Ridge Regression | 0.4241 | 0.8374 | 0.4202 | Low |
| **Tuned Decision Tree** | **0.3046** | **0.9161** | **0.3122** | **Controlled ✅** |

**🏆 Best Model: Tuned Decision Tree** (`max_depth=7, min_samples_split=10`)  
Explains **91.6%** of house price variance with minimal overfitting.

---

## 📈 Performance Charts

### Overfitting Detection + CV Comparison + Actual vs Predicted
![Main Plot](assets/task3_main_plot.png)

### Final Model Comparison (RMSE & R²)
![Comparison Plot](assets/task3_comparison_plot.png)

### GridSearchCV Hyperparameter Heatmap
![GridSearch Heatmap](assets/task3_gridsearch_heatmap.png)

---

## 🗂️ Repository Structure

```
ml-house-price-task3/
│
├── notebooks/
│   └── AI_ML_Task3_Model_Validation_Tuning.ipynb   # Full 10-step implementation
│
├── reports/
│   └── AI_ML_Task3_Report.pdf                      # 3-page professional report
│
├── models/
│   └── task3_best_model.pkl                        # Tuned Decision Tree (joblib)
│
├── assets/
│   ├── task3_main_plot.png                         # Overfitting + CV + Actual vs Predicted
│   ├── task3_comparison_plot.png                   # Final RMSE & R² comparison
│   └── task3_gridsearch_heatmap.png                # GridSearchCV parameter heatmap
│
└── README.md
```

---

## 🧰 Tech Stack

| Tool | Purpose |
|---|---|
| Python 3.12 | Core language |
| pandas / NumPy | Data manipulation |
| scikit-learn | Models, GridSearchCV, cross_val_score |
| matplotlib | Visualisation & heatmaps |
| joblib | Model serialisation |
| Jupyter Notebook | Interactive development |

---

## 🚀 Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/ml-house-price-task3.git
cd ml-house-price-task3
```

### 2. Install dependencies
```bash
pip install pandas numpy scikit-learn matplotlib joblib jupyter
```

### 3. Run the notebook
```bash
jupyter notebook notebooks/AI_ML_Task3_Model_Validation_Tuning.ipynb
```

### 4. Load the saved model
```python
import joblib
model = joblib.load('models/task3_best_model.pkl')
predictions = model.predict(X_test_scaled)
```

---

## 📋 Step-by-Step Pipeline

```
Step 1  → Import Libraries
Step 2  → Load & Prepare Dataset (California Housing)
Step 3  → Feature Scaling (StandardScaler)
Step 4  → Train-Test Split (80/20)
Step 5  → Detect Overfitting (Train vs Test RMSE gap analysis)
Step 6  → Cross-Validation (5-Fold CV on all models)
Step 7  → Hyperparameter Tuning (GridSearchCV: 12 combos × 5 folds = 60 fits)
Step 8  → Evaluate Optimised Model
Step 9  → Model Comparison Summary Table
Step 10 → Final Model Selection Justification
```

---

## 🔍 Key Concepts Demonstrated

- **Overfitting Detection** — comparing Train vs Test RMSE to spot memorisation
- **Bias-Variance Tradeoff** — controlling tree depth balances underfitting vs overfitting
- **5-Fold Cross-Validation** — more reliable than a single train-test split
- **GridSearchCV** — automated, exhaustive hyperparameter search with CV
- **Model Generalisation** — ensuring the model performs well on truly unseen data
- **Production Readiness** — saved, loadable model ready for deployment

---

## 🧪 Overfitting: Before vs After

| | Untuned Decision Tree | Tuned Decision Tree |
|---|---|---|
| Train RMSE | ~0.0000 ⚠️ | 0.2850 ✅ |
| Test RMSE | 0.4159 ⚠️ | 0.3046 ✅ |
| Gap | **0.4159** (severe) | **0.020** (controlled) |

The untuned tree memorised the entire training set (RMSE ≈ 0) but failed on unseen data. GridSearchCV eliminated this by finding the right depth constraints.

---

## 🔗 Related Projects

- 📁 [Task 2 — Feature Engineering & Model Comparison](https://github.com/YOUR_USERNAME/ml-house-price-prediction)

---

## 📄 Report

Full methodology, charts, and model justification available in [`reports/AI_ML_Task3_Report.pdf`](reports/AI_ML_Task3_Report.pdf)

---

## 🤝 Acknowledgements

Built as part of the **Maincrafts Technology AI/ML Internship Program**.  
Dataset: [California Housing Dataset](https://scikit-learn.org/stable/datasets/real_world.html) via scikit-learn.

---

⭐ If this project helped you, consider giving it a star!
